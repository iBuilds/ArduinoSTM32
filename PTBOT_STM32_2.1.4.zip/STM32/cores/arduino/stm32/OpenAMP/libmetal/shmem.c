#ifdef VIRTIOCON

#include "libmetal/lib/shmem.c"

#endif /* VIRTIOCON */
