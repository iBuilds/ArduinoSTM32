#ifndef PTKidsBITRobotPro_h
#define PTKidsBITRobotPro_h

#include <EEPROM.h>
#include <Servo.h>
#include <NewPing/src/NewPing.h>
#include <FastIMU/src/FastIMU.h>
#include <Adafruit_NeoPixel/Adafruit_NeoPixel.h>
#include <Adafruit_SSD1306/Adafruit_SSD1306.h>

#define buzzer_pin PB5
#define servo_pin_0 PA13
#define servo_pin_1 PA14
#define motor_left_1 PB8
#define motor_left_2 PB9
#define motor_right_1 PA9
#define motor_right_2 PA10
#define mux_pin_0 PC14
#define mux_pin_1 PC15
#define mux_pin_2 PB12
#define mux_pin_3 PB13
#define mux_sig_pin PA5
#define led_color_pin PA15
#define button_a_pin PB14
#define button_b_pin PB15
#define button_c_pin PA8
#define sonar_trigger_pin PB4
#define sonar_echo_pin PB3

#define red pixels.Color(255, 0, 0)
#define green pixels.Color(0, 255, 0)
#define blue pixels.Color(0, 0, 255)
#define white pixels.Color(255, 255, 255)
#define black pixels.Color(0, 0, 0)

String inputString = "";
bool stringComplete = false;
int mux_control_pin[] = {mux_pin_0, mux_pin_1, mux_pin_2, mux_pin_3};
int mux_channel[16][4] = {
    {0, 0, 0, 0}, // channel 0
    {1, 0, 0, 0}, // channel 1
    {0, 1, 0, 0}, // channel 2
    {1, 1, 0, 0}, // channel 3
    {0, 0, 1, 0}, // channel 4
    {1, 0, 1, 0}, // channel 5
    {0, 1, 1, 0}, // channel 6
    {1, 1, 1, 0}, // channel 7
    {0, 0, 0, 1}, // channel 8
    {1, 0, 0, 1}, // channel 9
    {0, 1, 0, 1}, // channel 10
    {1, 1, 0, 1}, // channel 11
    {0, 0, 1, 1}, // channel 12
    {1, 0, 1, 1}, // channel 13
    {0, 1, 1, 1}, // channel 14
    {1, 1, 1, 1}  // channel 15
};
byte calibrate_mode = 1;
int front_line_cal[] = {0, 0, 0, 0, 0, 0, 0};
int back_line_cal[] = {0, 0, 0, 0, 0, 0, 0};
int left_line_cal[] = {0, 0, 0, 0, 0};
int right_line_cal[] = {0, 0, 0, 0, 0};
int front_background_cal[] = {0, 0, 0, 0, 0, 0, 0};
int back_background_cal[] = {0, 0, 0, 0, 0, 0, 0};
int left_background_cal[] = {0, 0, 0, 0, 0};
int right_background_cal[] = {0, 0, 0, 0, 0};
int last_position_front = 0;
int last_position_back = 0;
int last_position_left = 0;
int last_position_right = 0;
int brake_power = 0;
int compensate_motor[] = {0, 0};
bool servo_attacted[] = {0, 0};
unsigned long timer_button_c = 0;
unsigned long timer_button_b = 0;
unsigned long time_gyro = 0;
float time_step_gyro = 0.01;
float rotation = 0;
float previous_error_fn = 0;

Servo servo_0;
Servo servo_1;
NewPing sonar(sonar_trigger_pin, sonar_echo_pin, 999999999);
calData calib = {0};
MPU6500 IMU;
GyroData gyroData;
Adafruit_NeoPixel pixels(24, led_color_pin, NEO_GRB);
Adafruit_SSD1306 display(128, 64, &Wire, -1);
HardwareSerial Serial3(PB11, PB10);
HardwareTimer timer(TIM1);
uint32_t color_set[24];

String splitString(String data, int index) {
  int found = 0;
  int strIndex[] = {0, -1};
  int maxIndex = data.length() - 1;

  for (int i = 0; i <= maxIndex && found <= index; i++) {
    if (data.charAt(i) == ',' || i == maxIndex) {
      found++;
      strIndex[0] = strIndex[1] + 1;
      strIndex[1] = (i == maxIndex) ? i + 1 : i;
    }
  }

  return found > index ? data.substring(strIndex[0], strIndex[1]) : "";
}

void playSound(int frequency, int duration) {
  unsigned long startTime = millis();
  unsigned long halfPeriod = 1000000L / frequency / 2;
  pinMode(buzzer_pin, OUTPUT);
  while (millis() - startTime < duration) {
    digitalWrite(buzzer_pin, HIGH);
    delayMicroseconds(halfPeriod);
    digitalWrite(buzzer_pin, LOW);
    delayMicroseconds(halfPeriod);
  }
  pinMode(buzzer_pin, INPUT);
}

void servoWrite(byte servo, int degree) {
  if (degree < 0) degree = 0;
  else if (degree > 180) degree = 180;
  if (servo == 0) {
    if (servo_attacted[0] == 0) {
      servo_0.attach(servo_pin_0);
      servo_attacted[0] = 1;
    }
    servo_0.write(degree);
  }
  else if (servo == 1) {
    if (servo_attacted[1] == 0) {
      servo_1.attach(servo_pin_1);
      servo_attacted[1] = 1;
    }
    servo_1.write(degree);
  }
}

void setCompensateMotor(int left, int right) {
  compensate_motor[0] = left;
  compensate_motor[1] = right;
}

void motorWrite(int speed_left, int speed_right) {
  if (speed_left > 255) speed_left = 255;
  else if (speed_left < -255) speed_left = -255;
  if (speed_right > 255) speed_right = 255;
  else if (speed_right < -255) speed_right = -255;

  if (speed_left > 0) {
    analogWrite(motor_left_1, speed_left + compensate_motor[0]);
    analogWrite(motor_left_2, 0);
  }
  else if (speed_left < 0) {
    analogWrite(motor_left_1, 0);
    analogWrite(motor_left_2, abs(speed_left) + compensate_motor[0]);
  }
  else {
    analogWrite(motor_left_1, brake_power);
    analogWrite(motor_left_2, brake_power);
  }

  if (speed_right > 0) {
    analogWrite(motor_right_1, speed_right + compensate_motor[1]);
    analogWrite(motor_right_2, 0);
  }
  else if (speed_right < 0) {
    analogWrite(motor_right_1, 0);
    analogWrite(motor_right_2, abs(speed_right) + compensate_motor[1]);
  }
  else {
    analogWrite(motor_right_1, brake_power);
    analogWrite(motor_right_2, brake_power);
  }
}

void setPowerBrake(int power) {
  if (power > 255) power = 255;
  else if (power < 0) power = 0;
  brake_power = power;
}

float readRotation() {
  time_gyro = millis();
  IMU.update();
  IMU.getGyro(&gyroData);
  rotation = (rotation + (gyroData.gyroZ * .015267f * time_step_gyro * 1.21) * (180 / PI));
  delay((time_step_gyro * 1000) - (millis() - time_gyro));
  return -rotation;
}

void resetGyro() {
  rotation = 0;
}

bool readButtonA() {
  //  if (digitalRead(button_a_pin) == 0) {
  //    unsigned long int timer = millis();
  //    while (1) {
  //      if (digitalRead(button_a_pin) == 1) break;
  //      if (millis() - timer > 50) return 1;
  //    }
  //  }
  return !digitalRead(button_a_pin);;
}

bool readButtonB() {
  //  if (digitalRead(button_b_pin) == 0) {
  //    unsigned long int timer = millis();
  //    while (1) {
  //      if (digitalRead(button_b_pin) == 1) break;
  //      if (millis() - timer > 50) return 1;
  //    }
  //  }
  return !digitalRead(button_b_pin);
}

bool readButtonC() {
  //  if (digitalRead(button_c_pin) == 0) {
  //    unsigned long int timer = millis();
  //    while (1) {
  //      if (digitalRead(button_c_pin) == 1) break;
  //      if (millis() - timer > 50) return 1;
  //    }
  //  }
  return !digitalRead(button_c_pin);
}

void updateLed() {
  pinMode(led_color_pin, OUTPUT);
  delayMicroseconds(100);
  pixels.show();
  pixels.show();
  delayMicroseconds(100);
  pinMode(led_color_pin, INPUT);
}

void turnOnLed(char sensor) {
  if (sensor == 'f') {
    pixels.setPixelColor(0, color_set[0]);
    pixels.setPixelColor(1, color_set[1]);
    pixels.setPixelColor(2, color_set[2]);
    pixels.setPixelColor(3, color_set[3]);
    pixels.setPixelColor(4, color_set[4]);
    pixels.setPixelColor(5, color_set[5]);
    pixels.setPixelColor(6, color_set[6]);
  }
  else if (sensor == 'b') {
    pixels.setPixelColor(12, color_set[12]);
    pixels.setPixelColor(13, color_set[13]);
    pixels.setPixelColor(14, color_set[14]);
    pixels.setPixelColor(15, color_set[15]);
    pixels.setPixelColor(16, color_set[16]);
    pixels.setPixelColor(17, color_set[17]);
    pixels.setPixelColor(18, color_set[18]);
  }
  else if (sensor == 'l') {
    pixels.setPixelColor(7, color_set[7]);
    pixels.setPixelColor(8, color_set[8]);
    pixels.setPixelColor(9, color_set[9]);
    pixels.setPixelColor(10, color_set[10]);
    pixels.setPixelColor(11, color_set[11]);
  }
  else if (sensor == 'r') {
    pixels.setPixelColor(19, color_set[19]);
    pixels.setPixelColor(20, color_set[20]);
    pixels.setPixelColor(21, color_set[21]);
    pixels.setPixelColor(22, color_set[22]);
    pixels.setPixelColor(23, color_set[23]);
  }
  updateLed();
}

void turnOffLed(char sensor) {
  if (sensor == 'f') {
    pixels.setPixelColor(0, black);
    pixels.setPixelColor(1, black);
    pixels.setPixelColor(2, black);
    pixels.setPixelColor(3, black);
    pixels.setPixelColor(4, black);
    pixels.setPixelColor(5, black);
    pixels.setPixelColor(6, black);
  }
  else if (sensor == 'b') {
    pixels.setPixelColor(12, black);
    pixels.setPixelColor(13, black);
    pixels.setPixelColor(14, black);
    pixels.setPixelColor(15, black);
    pixels.setPixelColor(16, black);
    pixels.setPixelColor(17, black);
    pixels.setPixelColor(18, black);
  }
  else if (sensor == 'l') {
    pixels.setPixelColor(7, black);
    pixels.setPixelColor(8, black);
    pixels.setPixelColor(9, black);
    pixels.setPixelColor(10, black);
    pixels.setPixelColor(11, black);
  }
  else if (sensor == 'r') {
    pixels.setPixelColor(19, black);
    pixels.setPixelColor(20, black);
    pixels.setPixelColor(21, black);
    pixels.setPixelColor(22, black);
    pixels.setPixelColor(23, black);
  }
  updateLed();
}

void turnOnLed() {
  for (int i = 0; i < pixels.numPixels(); i++) {
    pixels.setPixelColor(i, color_set[i]);
  }
  updateLed();
}

void turnOffLed() {
  for (int i = 0; i < pixels.numPixels(); i++) {
    pixels.setPixelColor(i, black);
  }
  updateLed();
}

void setLedColor(char sensor, uint32_t led1, uint32_t led2, uint32_t led3, uint32_t led4, uint32_t led5, uint32_t led6, uint32_t led7) {
  if (sensor == 'f') {
    color_set[0] = led1;
    color_set[1] = led2;
    color_set[2] = led3;
    color_set[3] = led4;
    color_set[4] = led5;
    color_set[5] = led6;
    color_set[6] = led7;
  }
  else if (sensor == 'b') {
    color_set[12] = led1;
    color_set[13] = led2;
    color_set[14] = led3;
    color_set[15] = led4;
    color_set[16] = led5;
    color_set[17] = led6;
    color_set[18] = led7;
  }
  turnOnLed();
}

void setLedColor(char sensor, uint32_t led1, uint32_t led2, uint32_t led3, uint32_t led4, uint32_t led5) {
  if (sensor == 'l') {
    color_set[7] = led1;
    color_set[8] = led2;
    color_set[9] = led3;
    color_set[10] = led4;
    color_set[11] = led5;
  }
  else if (sensor == 'r') {
    color_set[19] = led1;
    color_set[20] = led2;
    color_set[21] = led3;
    color_set[22] = led4;
    color_set[23] = led5;
  }
  turnOnLed();
}

void setLedColor(uint32_t color) {
  for (int i = 0; i < pixels.numPixels(); i++) color_set[i] = color;
  turnOnLed();
}

void setLedBrightness(byte brightness) {
  pixels.setBrightness(brightness);
  turnOnLed();
}

uint32_t wheel(byte wheel_pos) {
  wheel_pos = 255 - wheel_pos;
  if (wheel_pos < 85) {
    return pixels.Color(255 - wheel_pos * 3, 0, wheel_pos * 3);
  }
  if (wheel_pos < 170) {
    wheel_pos -= 85;
    return pixels.Color(0, wheel_pos * 3, 255 - wheel_pos * 3);
  }
  wheel_pos -= 170;
  return pixels.Color(wheel_pos * 3, 255 - wheel_pos * 3, 0);
}

void setCalibrateMode(byte mode) {
  calibrate_mode = mode;
}

int readLineSensor(byte channel) {
  if (pixels.getBrightness() < 255) setLedBrightness(255);

  if (channel > 13 && channel < 18 || channel > 19) {
    if (channel == 14) return analogRead(PB1);
    else if (channel == 15) return analogRead(PB0);
    else if (channel == 16) return analogRead(PA7);
    else if (channel == 17) return analogRead(PA6);
    else if (channel == 20) return analogRead(PA4);
    else if (channel == 21) return analogRead(PA3);
    else if (channel == 22) return analogRead(PA2);
    else if (channel == 23) return analogRead(PA1);
  }
  else {
    if (channel == 0) channel = 9;
    else if (channel == 1) channel = 8;
    else if (channel == 2) channel = 10;
    else if (channel == 3) channel = 11;
    else if (channel == 4) channel = 12;
    else if (channel == 5) channel = 13;
    else if (channel == 6) channel = 14;
    else if (channel == 7) channel = 7;
    else if (channel == 8) channel = 6;
    else if (channel == 9) channel = 5;
    else if (channel == 10) channel = 4;
    else if (channel == 11) channel = 3;
    else if (channel == 12) channel = 2;
    else if (channel == 13) channel = 1;
    else if (channel == 18) channel = 15;
    else if (channel == 19) channel = 0;

    for (int i = 0; i < 4; i ++) {
      digitalWrite(mux_control_pin[i], mux_channel[channel][i]);
    }
    delayMicroseconds(1000);
    return analogRead(mux_sig_pin);
  }
}

int readDistance() {
  int _distance = sonar.ping_cm();
  if (_distance == 0) return 999;
  else return _distance;
}

void saveLineToEEPROM() {
  EEPROM.update(0, front_line_cal[0] / 4);
  EEPROM.update(1, front_line_cal[1] / 4);
  EEPROM.update(2, front_line_cal[2] / 4);
  EEPROM.update(3, front_line_cal[3] / 4);
  EEPROM.update(4, front_line_cal[4] / 4);
  EEPROM.update(5, front_line_cal[5] / 4);
  EEPROM.update(6, front_line_cal[6] / 4);

  EEPROM.update(7, back_line_cal[0] / 4);
  EEPROM.update(8, back_line_cal[1] / 4);
  EEPROM.update(9, back_line_cal[2] / 4);
  EEPROM.update(10, back_line_cal[3] / 4);
  EEPROM.update(11, back_line_cal[4] / 4);
  EEPROM.update(12, back_line_cal[5] / 4);
  EEPROM.update(13, back_line_cal[6] / 4);

  EEPROM.update(14, left_line_cal[0] / 4);
  EEPROM.update(15, left_line_cal[1] / 4);
  EEPROM.update(16, left_line_cal[2] / 4);
  EEPROM.update(17, left_line_cal[3] / 4);
  EEPROM.update(18, left_line_cal[4] / 4);

  EEPROM.update(19, right_line_cal[0] / 4);
  EEPROM.update(20, right_line_cal[1] / 4);
  EEPROM.update(21, right_line_cal[2] / 4);
  EEPROM.update(22, right_line_cal[3] / 4);
  EEPROM.update(23, right_line_cal[4] / 4);

  EEPROM.update(24, front_background_cal[0] / 4);
  EEPROM.update(25, front_background_cal[1] / 4);
  EEPROM.update(26, front_background_cal[2] / 4);
  EEPROM.update(27, front_background_cal[3] / 4);
  EEPROM.update(28, front_background_cal[4] / 4);
  EEPROM.update(29, front_background_cal[5] / 4);
  EEPROM.update(30, front_background_cal[6] / 4);

  EEPROM.update(31, back_background_cal[0] / 4);
  EEPROM.update(32, back_background_cal[1] / 4);
  EEPROM.update(33, back_background_cal[2] / 4);
  EEPROM.update(34, back_background_cal[3] / 4);
  EEPROM.update(35, back_background_cal[4] / 4);
  EEPROM.update(36, back_background_cal[5] / 4);
  EEPROM.update(37, back_background_cal[6] / 4);

  EEPROM.update(38, left_background_cal[0] / 4);
  EEPROM.update(39, left_background_cal[1] / 4);
  EEPROM.update(40, left_background_cal[2] / 4);
  EEPROM.update(41, left_background_cal[3] / 4);
  EEPROM.update(42, left_background_cal[4] / 4);

  EEPROM.update(43, right_background_cal[0] / 4);
  EEPROM.update(44, right_background_cal[1] / 4);
  EEPROM.update(45, right_background_cal[2] / 4);
  EEPROM.update(46, right_background_cal[3] / 4);
  EEPROM.update(47, right_background_cal[4] / 4);
}

void readLineFromEEPROM() {
  front_line_cal[0] = EEPROM.read(0) * 4;
  front_line_cal[1] = EEPROM.read(1) * 4;
  front_line_cal[2] = EEPROM.read(2) * 4;
  front_line_cal[3] = EEPROM.read(3) * 4;
  front_line_cal[4] = EEPROM.read(4) * 4;
  front_line_cal[5] = EEPROM.read(5) * 4;
  front_line_cal[6] = EEPROM.read(6) * 4;

  back_line_cal[0] = EEPROM.read(7) * 4;
  back_line_cal[1] = EEPROM.read(8) * 4;
  back_line_cal[2] = EEPROM.read(9) * 4;
  back_line_cal[3] = EEPROM.read(10) * 4;
  back_line_cal[4] = EEPROM.read(11) * 4;
  back_line_cal[5] = EEPROM.read(12) * 4;
  back_line_cal[6] = EEPROM.read(13) * 4;

  left_line_cal[0] = EEPROM.read(14) * 4;
  left_line_cal[1] = EEPROM.read(15) * 4;
  left_line_cal[2] = EEPROM.read(16) * 4;
  left_line_cal[3] = EEPROM.read(17) * 4;
  left_line_cal[4] = EEPROM.read(18) * 4;

  right_line_cal[0] = EEPROM.read(19) * 4;
  right_line_cal[1] = EEPROM.read(20) * 4;
  right_line_cal[2] = EEPROM.read(21) * 4;
  right_line_cal[3] = EEPROM.read(22) * 4;
  right_line_cal[4] = EEPROM.read(23) * 4;

  front_background_cal[0] = EEPROM.read(24) * 4;
  front_background_cal[1] = EEPROM.read(25) * 4;
  front_background_cal[2] = EEPROM.read(26) * 4;
  front_background_cal[3] = EEPROM.read(27) * 4;
  front_background_cal[4] = EEPROM.read(28) * 4;
  front_background_cal[5] = EEPROM.read(29) * 4;
  front_background_cal[6] = EEPROM.read(30) * 4;

  back_background_cal[0] = EEPROM.read(31) * 4;
  back_background_cal[1] = EEPROM.read(32) * 4;
  back_background_cal[2] = EEPROM.read(33) * 4;
  back_background_cal[3] = EEPROM.read(34) * 4;
  back_background_cal[4] = EEPROM.read(35) * 4;
  back_background_cal[5] = EEPROM.read(36) * 4;
  back_background_cal[6] = EEPROM.read(37) * 4;

  left_background_cal[0] = EEPROM.read(38) * 4;
  left_background_cal[1] = EEPROM.read(39) * 4;
  left_background_cal[2] = EEPROM.read(40) * 4;
  left_background_cal[3] = EEPROM.read(41) * 4;
  left_background_cal[4] = EEPROM.read(42) * 4;

  right_background_cal[0] = EEPROM.read(43) * 4;
  right_background_cal[1] = EEPROM.read(44) * 4;
  right_background_cal[2] = EEPROM.read(45) * 4;
  right_background_cal[3] = EEPROM.read(46) * 4;
  right_background_cal[4] = EEPROM.read(47) * 4;
}

void calibrateLineSensor(byte mode) {
  setLedBrightness(255);
  turnOffLed();
  if (mode == 1) {
    playSound(500, 100);
    playSound(1000, 100);
    unsigned long int timer = millis();
    bool led_state = 0;
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 0);
    display.println(F("Calibrating Line"));
    display.setCursor(18, 25);
    display.println(F("Place the robot"));
    display.setCursor(5, 37);
    display.println(F("on the black ground"));
    display.setCursor(7, 49);
    display.println(F("and press BUTTON A"));
    display.display();
    while (readButtonA() == 0) {
      if (millis() - timer <= 250) {
        if (led_state == 0) {
          turnOnLed('f');
          turnOnLed('b');
          turnOnLed('l');
          turnOnLed('r');
          led_state = 1;
        }
      }
      else if (millis() - timer > 250 && millis() - timer <= 500) {
        if (led_state == 1) {
          turnOffLed('f');
          turnOffLed('b');
          turnOffLed('l');
          turnOffLed('r');
          led_state = 0;
        }
      }
      else timer = millis();
    }
    playSound(1000, 100);
    turnOnLed('f');
    turnOnLed('b');
    turnOnLed('l');
    turnOnLed('r');
    delay(200);
    for (byte i = 0; i < 20; i ++) {
      for (byte j = 0; j < 7; j ++) front_line_cal[j] += readLineSensor(j);
      for (byte j = 0; j < 7; j ++) back_line_cal[j] += readLineSensor(j + 7);
      for (byte j = 0; j < 5; j ++) left_line_cal[j] += readLineSensor(j + 14);
      for (byte j = 0; j < 5; j ++) right_line_cal[j] += readLineSensor(j + 19);
      delay(50);
    }
    for (byte i = 0; i < 7; i ++) front_line_cal[i] = front_line_cal[i] / 20;
    for (byte i = 0; i < 7; i ++) back_line_cal[i] = back_line_cal[i] / 20;
    for (byte i = 0; i < 5; i ++) left_line_cal[i] = left_line_cal[i] / 20;
    for (byte i = 0; i < 5; i ++) right_line_cal[i] = right_line_cal[i] / 20;
    playSound(1000, 100);
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 0);
    display.println(F("Calibrating Line"));
    display.setCursor(18, 25);
    display.println(F("Place the robot"));
    display.setCursor(5, 37);
    display.println(F("on the white ground"));
    display.setCursor(7, 49);
    display.println(F("and press BUTTON A"));
    display.display();
    while (readButtonA() == 0) {
      if (millis() - timer <= 250) {
        if (led_state == 0) {
          turnOnLed('f');
          turnOnLed('b');
          turnOnLed('l');
          turnOnLed('r');
          led_state = 1;
        }
      }
      else if (millis() - timer > 250 && millis() - timer <= 500) {
        if (led_state == 1) {
          turnOffLed('f');
          turnOffLed('b');
          turnOffLed('l');
          turnOffLed('r');
          led_state = 0;
        }
      }
      else timer = millis();
    }
    playSound(1000, 100);
    turnOnLed('f');
    turnOnLed('b');
    turnOnLed('l');
    turnOnLed('r');
    delay(200);
    for (byte i = 0; i < 20; i ++) {
      for (byte j = 0; j < 7; j ++) front_background_cal[j] += readLineSensor(j);
      for (byte j = 0; j < 7; j ++) back_background_cal[j] += readLineSensor(j + 7);
      for (byte j = 0; j < 5; j ++) left_background_cal[j] += readLineSensor(j + 14);
      for (byte j = 0; j < 5; j ++) right_background_cal[j] += readLineSensor(j + 19);
      delay(50);
    }
    for (byte i = 0; i < 7; i ++) front_background_cal[i] = front_background_cal[i] / 20;
    for (byte i = 0; i < 7; i ++) back_background_cal[i] = back_background_cal[i] / 20;
    for (byte i = 0; i < 5; i ++) left_background_cal[i] = left_background_cal[i] / 20;
    for (byte i = 0; i < 5; i ++) right_background_cal[i] = right_background_cal[i] / 20;
  }
  else if (mode == 2) {
    playSound(500, 100);
    playSound(1000, 100);
    unsigned long int timer = millis();
    bool led_state = 0;
    byte brightness = 0;
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 0);
    display.println(F("Calibrating Line"));
    display.setCursor(9, 25);
    display.println(F("Place front sensor"));
    display.setCursor(5, 37);
    display.println(F("on the black ground"));
    display.setCursor(7, 49);
    display.println(F("and press BUTTON A"));
    display.display();
    while (readButtonA() == 0) {
      if (millis() - timer <= 250) {
        if (led_state == 0) {
          turnOnLed('f');
          led_state = 1;
        }
      }
      else if (millis() - timer > 250 && millis() - timer <= 500) {
        if (led_state == 1) {
          turnOffLed('f');
          led_state = 0;
        }
      }
      else timer = millis();
    }
    playSound(1000, 100);
    turnOnLed('f');
    delay(200);
    for (byte i = 0; i < 20; i ++) {
      for (byte j = 0; j < 7; j ++) front_line_cal[j] += readLineSensor(j);
      delay(50);
    }
    for (byte i = 0; i < 7; i ++) front_line_cal[i] = front_line_cal[i] / 20;
    playSound(1000, 100);
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 0);
    display.println(F("Calibrating Line"));
    display.setCursor(9, 25);
    display.println(F("Place front sensor"));
    display.setCursor(5, 37);
    display.println(F("on the white ground"));
    display.setCursor(7, 49);
    display.println(F("and press BUTTON A"));
    display.display();
    while (readButtonA() == 0) {
      if (millis() - timer <= 250) {
        if (led_state == 0) {
          turnOnLed('f');
          led_state = 1;
        }
      }
      else if (millis() - timer > 250 && millis() - timer <= 500) {
        if (led_state == 1) {
          turnOffLed('f');
          led_state = 0;
        }
      }
      else timer = millis();
    }
    playSound(1000, 100);
    turnOnLed('f');
    delay(200);
    for (byte i = 0; i < 20; i ++) {
      for (byte j = 0; j < 7; j ++) front_background_cal[j] += readLineSensor(j);
      delay(50);
    }
    for (byte i = 0; i < 7; i ++) front_background_cal[i] = front_background_cal[i] / 20;
    turnOffLed('f');
    playSound(1000, 100);
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 0);
    display.println(F("Calibrating Line"));
    display.setCursor(12, 25);
    display.println(F("Place back sensor"));
    display.setCursor(5, 37);
    display.println(F("on the black ground"));
    display.setCursor(7, 49);
    display.println(F("and press BUTTON A"));
    display.display();
    while (readButtonA() == 0) {
      if (millis() - timer <= 250) {
        if (led_state == 0) {
          turnOnLed('b');
          led_state = 1;
        }
      }
      else if (millis() - timer > 250 && millis() - timer <= 500) {
        if (led_state == 1) {
          turnOffLed('b');
          led_state = 0;
        }
      }
      else timer = millis();
    }
    playSound(1000, 100);
    turnOnLed('b');
    delay(200);
    for (byte i = 0; i < 20; i ++) {
      for (byte j = 0; j < 7; j ++) back_line_cal[j] += readLineSensor(j + 7);
      delay(50);
    }
    for (byte i = 0; i < 7; i ++) back_line_cal[i] = back_line_cal[i] / 20;
    playSound(1000, 100);
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 0);
    display.println(F("Calibrating Line"));
    display.setCursor(12, 25);
    display.println(F("Place back sensor"));
    display.setCursor(5, 37);
    display.println(F("on the white ground"));
    display.setCursor(7, 49);
    display.println(F("and press BUTTON A"));
    display.display();
    while (readButtonA() == 0) {
      if (millis() - timer <= 250) {
        if (led_state == 0) {
          turnOnLed('b');
          led_state = 1;
        }
      }
      else if (millis() - timer > 250 && millis() - timer <= 500) {
        if (led_state == 1) {
          turnOffLed('b');
          led_state = 0;
        }
      }
      else timer = millis();
    }
    playSound(1000, 100);
    turnOnLed('b');
    delay(200);
    for (byte i = 0; i < 20; i ++) {
      for (byte j = 0; j < 7; j ++) back_background_cal[j] += readLineSensor(j + 7);
      delay(50);
    }
    for (byte i = 0; i < 7; i ++) back_background_cal[i] = back_background_cal[i] / 20;
    turnOffLed('b');
    playSound(1000, 100);
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 0);
    display.println(F("Calibrating Line"));
    display.setCursor(12, 25);
    display.println(F("Place left sensor"));
    display.setCursor(5, 37);
    display.println(F("on the black ground"));
    display.setCursor(7, 49);
    display.println(F("and press BUTTON A"));
    display.display();
    while (readButtonA() == 0) {
      if (millis() - timer <= 250) {
        if (led_state == 0) {
          turnOnLed('l');
          led_state = 1;
        }
      }
      else if (millis() - timer > 250 && millis() - timer <= 500) {
        if (led_state == 1) {
          turnOffLed('l');
          led_state = 0;
        }
      }
      else timer = millis();
    }
    playSound(1000, 100);
    turnOnLed('l');
    delay(200);
    for (byte i = 0; i < 20; i ++) {
      for (byte j = 0; j < 5; j ++) left_line_cal[j] += readLineSensor(j + 14);
      delay(50);
    }
    for (byte i = 0; i < 5; i ++) left_line_cal[i] = left_line_cal[i] / 20;
    playSound(1000, 100);
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 0);
    display.println(F("Calibrating Line"));
    display.setCursor(12, 25);
    display.println(F("Place left sensor"));
    display.setCursor(5, 37);
    display.println(F("on the white ground"));
    display.setCursor(7, 49);
    display.println(F("and press BUTTON A"));
    display.display();
    while (readButtonA() == 0) {
      if (millis() - timer <= 250) {
        if (led_state == 0) {
          turnOnLed('l');
          led_state = 1;
        }
      }
      else if (millis() - timer > 250 && millis() - timer <= 500) {
        if (led_state == 1) {
          turnOffLed('l');
          led_state = 0;
        }
      }
      else timer = millis();
    }
    playSound(1000, 100);
    turnOnLed('l');
    delay(200);
    for (byte i = 0; i < 20; i ++) {
      for (byte j = 0; j < 5; j ++) left_background_cal[j] += readLineSensor(j + 14);
      delay(50);
    }
    for (byte i = 0; i < 5; i ++) left_background_cal[i] = left_background_cal[i] / 20;
    turnOffLed('l');
    playSound(1000, 100);
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 0);
    display.println(F("Calibrating Line"));
    display.setCursor(9, 25);
    display.println(F("Place right sensor"));
    display.setCursor(5, 37);
    display.println(F("on the black ground"));
    display.setCursor(7, 49);
    display.println(F("and press BUTTON A"));
    display.display();
    while (readButtonA() == 0) {
      if (millis() - timer <= 250) {
        if (led_state == 0) {
          turnOnLed('r');
          led_state = 1;
        }
      }
      else if (millis() - timer > 250 && millis() - timer <= 500) {
        if (led_state == 1) {
          turnOffLed('r');
          led_state = 0;
        }
      }
      else timer = millis();
    }
    playSound(1000, 100);
    turnOnLed('r');
    delay(200);
    for (byte i = 0; i < 20; i ++) {
      for (byte j = 0; j < 5; j ++) right_line_cal[j] += readLineSensor(j + 19);
      delay(50);
    }
    for (byte i = 0; i < 5; i ++) right_line_cal[i] = right_line_cal[i] / 20;
    playSound(1000, 100);
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 0);
    display.println(F("Calibrating Line"));
    display.setCursor(9, 25);
    display.println(F("Place right sensor"));
    display.setCursor(5, 37);
    display.println(F("on the white ground"));
    display.setCursor(7, 49);
    display.println(F("and press BUTTON A"));
    display.display();
    while (readButtonA() == 0) {
      if (millis() - timer <= 250) {
        if (led_state == 0) {
          turnOnLed('r');
          led_state = 1;
        }
      }
      else if (millis() - timer > 250 && millis() - timer <= 500) {
        if (led_state == 1) {
          turnOffLed('r');
          led_state = 0;
        }
      }
      else timer = millis();
    }
    playSound(1000, 100);
    turnOnLed('r');
    delay(200);
    for (byte i = 0; i < 20; i ++) {
      for (byte j = 0; j < 5; j ++) right_background_cal[j] += readLineSensor(j + 19);
      delay(50);
    }
    for (byte i = 0; i < 5; i ++) right_background_cal[i] = right_background_cal[i] / 20;
    turnOffLed('l');
  }
  playSound(1000, 100);
  playSound(500, 100);
  turnOnLed();
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(16, 0);
  display.println(F("Calibrating Line"));
  display.setCursor(16, 25);
  display.println(F("Calibrating done"));
  display.display();
  delay(1000);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.display();
  saveLineToEEPROM();
}

void calibrateIMU() {
  playSound(500, 100);
  playSound(1000, 100);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(18, 0);
  display.println(F("Calibrating IMU"));
  display.setCursor(18, 25);
  display.println(F("Place the robot"));
  display.setCursor(23, 37);
  display.println(F("on the ground"));
  display.display();
  delay(3000);
  IMU.init(calib, 0x68);
  IMU.calibrateAccelGyro(&calib);
  IMU.init(calib, 0x68);
  IMU.setGyroRange(500);
  IMU.setAccelRange(2);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(18, 0);
  display.println(F("Calibrating IMU"));
  display.setCursor(16, 25);
  display.println(F("Calibrating done"));
  display.display();
  playSound(1000, 100);
  playSound(500, 100);
  delay(1000);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.display();
}

int readPosition(char sensor) {
  int average = 0;
  int sum_value = 0;
  bool on_line = 0;
  if (sensor == 'f') {
    for (byte i = 0; i < 7; i ++) {
      int value_sensor;
      value_sensor = map(readLineSensor(i), front_line_cal[i], front_background_cal[i], 100, 0);
      if (value_sensor < 0) {
        value_sensor = 0;
      }
      else if (value_sensor > 100) {
        value_sensor = 100;
      }
      if (value_sensor > 50) {
        on_line = 1;
        average += (long)value_sensor * (i * 100);
        sum_value += value_sensor;
      }
    }
    if (on_line == 0) {
      if (last_position_front < 6 * 100 / 2) {
        return -300;
      }
      else {
        return 300;
      }
    }
    last_position_front = average / sum_value;
    return last_position_front - 300;
  }
  else if (sensor == 'b') {
    for (byte i = 0; i < 7; i ++) {
      int value_sensor;
      value_sensor = map(readLineSensor(i + 7), back_line_cal[i], back_background_cal[i], 100, 0);
      if (value_sensor < 0) {
        value_sensor = 0;
      }
      else if (value_sensor > 100) {
        value_sensor = 100;
      }
      if (value_sensor > 50) {
        on_line = 1;
        average += (long)value_sensor * (i * 100);
        sum_value += value_sensor;
      }
    }
    if (on_line == 0) {
      if (last_position_back < 6 * 100 / 2) {
        return -300;
      }
      else {
        return 300;
      }
    }
    last_position_back = average / sum_value;
    return last_position_back - 300;
  }
  else if (sensor == 'l') {
    for (byte i = 0; i < 5; i ++) {
      int value_sensor;
      value_sensor = map(readLineSensor(i + 14), left_line_cal[i], left_background_cal[i], 100, 0);
      if (value_sensor < 0) {
        value_sensor = 0;
      }
      else if (value_sensor > 100) {
        value_sensor = 100;
      }
      if (value_sensor > 50) {
        on_line = 1;
        average += (long)value_sensor * (i * 100);
        sum_value += value_sensor;
      }
    }
    if (on_line == 0) {
      if (last_position_left < 4 * 100 / 2) {
        return -200;
      }
      else {
        return 200;
      }
    }
    last_position_left = average / sum_value;
    return last_position_left - 200;
  }
  else if (sensor == 'r') {
    for (byte i = 0; i < 5; i ++) {
      int value_sensor;
      value_sensor = map(readLineSensor(i + 19), right_line_cal[i], right_background_cal[i], 100, 0);
      if (value_sensor < 0) {
        value_sensor = 0;
      }
      else if (value_sensor > 100) {
        value_sensor = 100;
      }
      if (value_sensor > 50) {
        on_line = 1;
        average += (long)value_sensor * (i * 100);
        sum_value += value_sensor;
      }
    }
    if (on_line == 0) {
      if (last_position_right < 4 * 100 / 2) {
        return 200;
      }
      else {
        return -200;
      }
    }
    last_position_right = average / sum_value;
    return 200 - last_position_right;
  }
}

char readJunction(char sensor) {
  if (sensor == 'f') {
    if (map(readLineSensor(0), front_line_cal[0], front_background_cal[0], 0, 100) < 50 && map(readLineSensor(6), front_line_cal[6], front_background_cal[6], 0, 100) < 50) return 'c';
    else if (map(readLineSensor(0), front_line_cal[0], front_background_cal[0], 0, 100) < 50 && map(readLineSensor(1), front_line_cal[1], front_background_cal[1], 0, 100) < 50 && map(readLineSensor(2), front_line_cal[2], front_background_cal[2], 0, 100) < 50 && map(readLineSensor(3), front_line_cal[3], front_background_cal[3], 0, 100) < 50 && map(readLineSensor(4), front_line_cal[4], front_background_cal[4], 0, 100) < 50 && map(readLineSensor(6), front_line_cal[6], front_background_cal[6], 0, 100) > 50) return 'r';
    else if (map(readLineSensor(6), front_line_cal[6], front_background_cal[6], 0, 100) < 50 && map(readLineSensor(5), front_line_cal[5], front_background_cal[5], 0, 100) < 50 && map(readLineSensor(4), front_line_cal[4], front_background_cal[4], 0, 100) < 50 && map(readLineSensor(3), front_line_cal[3], front_background_cal[3], 0, 100) < 50 && map(readLineSensor(2), front_line_cal[2], front_background_cal[2], 0, 100) < 50 && map(readLineSensor(0), front_line_cal[0], front_background_cal[0], 0, 100) > 50) return 'l';
    else return 'n';
  }
  else if (sensor == 'b') {
    if (map(readLineSensor(7), back_line_cal[0], back_background_cal[0], 0, 100) < 50 && map(readLineSensor(13), back_line_cal[6], back_background_cal[6], 0, 100) < 50) return 'c';
    else if (map(readLineSensor(7), back_line_cal[0], back_background_cal[0], 0, 100) < 50 && map(readLineSensor(8), back_line_cal[1], back_background_cal[1], 0, 100) < 50 && map(readLineSensor(9), back_line_cal[2], back_background_cal[2], 0, 100) < 50 && map(readLineSensor(10), back_line_cal[3], back_background_cal[3], 0, 100) < 50 && map(readLineSensor(11), back_line_cal[4], back_background_cal[4], 0, 100) < 50 && map(readLineSensor(13), back_line_cal[6], back_background_cal[6], 0, 100) > 50) return 'r';
    else if (map(readLineSensor(13), back_line_cal[6], back_background_cal[6], 0, 100) < 50 && map(readLineSensor(12), back_line_cal[5], back_background_cal[5], 0, 100) < 50 && map(readLineSensor(11), back_line_cal[4], back_background_cal[4], 0, 100) < 50 && map(readLineSensor(10), back_line_cal[3], back_background_cal[3], 0, 100) < 50 && map(readLineSensor(9), back_line_cal[2], back_background_cal[2], 0, 100) < 50 && map(readLineSensor(7), back_line_cal[0], back_background_cal[0], 0, 100) > 50) return 'l';
    else return 'n';
  }
}

void setToGo(char sensor) {
  unsigned long int timer = millis();
  unsigned long int timer_over = millis();
  bool on_offset = 0;
  if (sensor == 'f') {
    float error, pd_value, P, D, previous_error;
    while (1) {
      error = readPosition('f');
      P = error;
      D = error - previous_error;
      pd_value = (P * 0.4) + (D * 1.5);
      previous_error = error;
      motorWrite(-pd_value, pd_value);
      if (error > -50 && error < 50) on_offset = 1;
      else on_offset = 0;
      if (on_offset == 0) timer = millis();
      if (millis() - timer >= 30 || millis() - timer_over >= 2000) {
        motorWrite(0, 0);
        break;
      }
    }
  }
  else if (sensor == 'c') {
    float error_left, error_right, pd_value_left, pd_value_right, P_left, P_right, D_left, D_right, previous_error_left, previous_error_right;
    while (1) {
      error_left = readPosition('l');
      error_right = readPosition('r');
      P_left = error_left;
      P_right = error_right;
      D_left = error_left - previous_error_left;
      D_right = error_right - previous_error_right;
      pd_value_left = (P_left * 0.7) + (D_left * 10);
      pd_value_right = (P_right * 0.7) + (D_right * 10);
      previous_error_left = error_left;
      previous_error_right = error_right;
      motorWrite(-pd_value_left, -pd_value_right);
      if (error_left > -50 && error_left < 50 && error_right > -50 && error_right < 50) on_offset = 1;
      else on_offset = 0;
      if (on_offset == 0) timer = millis();
      if (millis() - timer >= 30 || millis() - timer_over >= 2000) {
        motorWrite(0, 0);
        break;
      }
    }
  }
  else if (sensor == 'b') {
    float error, pd_value, P, D, previous_error;
    while (1) {
      error = readPosition('b');
      P = error;
      D = error - previous_error;
      pd_value = (P * 0.4) + (D * 1.5);
      previous_error = error;
      motorWrite(-pd_value, pd_value);
      if (error > -50 && error < 50) on_offset = 1;
      else on_offset = 0;
      if (on_offset == 0) timer = millis();
      if (millis() - timer >= 30 || millis() - timer_over >= 2000) {
        motorWrite(0, 0);
        break;
      }
    }
  }
}

void forwardLine(int base_speed, float kp, float kd) {
  float error, pd_value, P, D, left_motor_speed, right_motor_speed;
  if (readJunction('f') != 'n') {
    motorWrite(base_speed, base_speed);
  }
  else {
    error = readPosition('f');
    P = error;
    D = error - previous_error_fn;
    pd_value = (P * kp) + (D * kd);
    previous_error_fn = error;
    left_motor_speed = base_speed - pd_value;
    right_motor_speed = base_speed + pd_value;
    motorWrite(left_motor_speed, right_motor_speed);
  }
}

void forwardLineTime(int base_speed, float kp, float kd, unsigned int time) {
  float error, pd_value, P, D, previous_error, left_motor_speed, right_motor_speed;
  unsigned long int timer = millis();
  while (1) {
    if (readJunction('f') != 'n') {
      motorWrite(base_speed, base_speed);
    }
    else {
      error = readPosition('f');
      P = error;
      D = error - previous_error;
      pd_value = (P * kp) + (D * kd);
      previous_error = error;
      left_motor_speed = base_speed - pd_value;
      right_motor_speed = base_speed + pd_value;
      motorWrite(left_motor_speed, right_motor_speed);
    }
    if (millis() - timer >= time) {
      motorWrite(0, 0);
      break;
    }
  }
}

void forwardLine(int base_speed, float kp, float kd, char junction, char stop_point) {
  float error, pd_value, P, D, previous_error, left_motor_speed, right_motor_speed;
  while (1) {
    if (readJunction('f') != 'n') {
      motorWrite(base_speed, base_speed);
    }
    else {
      delay(100);
      break;
    }
  }
  while (1) {
    if (readJunction('f') != 'n') {
      motorWrite(base_speed, base_speed);
    }
    else {
      error = readPosition('f');
      P = error;
      D = error - previous_error;
      pd_value = (P * kp) + (D * kd);
      previous_error = error;
      left_motor_speed = base_speed - pd_value;
      right_motor_speed = base_speed + pd_value;
      motorWrite(left_motor_speed, right_motor_speed);
    }
    if (junction == 'c') {
      if (readJunction('f') == 'c') {
        motorWrite(0, 0);
        break;
      }
    }
    else if (junction == 'l') {
      if (readJunction('f') == 'l') {
        motorWrite(0, 0);
        break;
      }
    }
    else if (junction == 'r') {
      if (readJunction('f') == 'r') {
        motorWrite(0, 0);
        break;
      }
    }
  }
  if (stop_point == 'f') {
    motorWrite(-255, -255);
    delay(30);
    motorWrite(0, 0);
  }
  else if (stop_point == 'c') {
    while (1) {
      if (readJunction('f') != 'n') {
        motorWrite(base_speed, base_speed);
      }
      else {
        error = readPosition('f');
        P = error;
        D = error - previous_error;
        pd_value = (P * kp) + (D * kd);
        previous_error = error;
        left_motor_speed = base_speed - pd_value;
        right_motor_speed = base_speed + pd_value;
        motorWrite(left_motor_speed, right_motor_speed);
      }
      if (junction == 'l') {
        if (readPosition('l') > -200 && readPosition('l') < 200) {
          motorWrite(-255, -255);
          delay(30);
          motorWrite(0, 0);
          break;
        }
      }
      else if (junction == 'c') {
        if (readPosition('l') > -200 && readPosition('l') < 200 && readPosition('r') > -200 && readPosition('r') < 200) {
          motorWrite(-255, -255);
          delay(30);
          motorWrite(0, 0);
          break;
        }
      }
      else if (junction == 'r') {
        if (readPosition('r') > -200 && readPosition('r') < 200) {
          motorWrite(-255, -255);
          delay(30);
          motorWrite(0, 0);
          break;
        }
      }
    }
  }
  else if (stop_point == 'b') {
    while (1) {
      if (readJunction('f') != 'n') {
        motorWrite(base_speed, base_speed);
      }
      else {
        error = readPosition('f');
        P = error;
        D = error - previous_error;
        pd_value = (P * kp) + (D * kd);
        previous_error = error;
        left_motor_speed = base_speed - pd_value;
        right_motor_speed = base_speed + pd_value;
        motorWrite(left_motor_speed, right_motor_speed);
      }
      if (readJunction('b') != 'n') {
        motorWrite(-255, -255);
        delay(30);
        motorWrite(0, 0);
        break;
      }
    }
  }
}

void forwardLine(int base_speed, float kp, float kd, char junction, char stop_point, int count) {
  float error, pd_value, P, D, previous_error, left_motor_speed, right_motor_speed;
  for (count; count > 0; count --) {
    while (1) {
      if (readJunction('f') != 'n') {
        motorWrite(base_speed, base_speed);
      }
      else {
        delay(100);
        break;
      }
    }
    while (1) {
      if (readJunction('f') != 'n') {
        motorWrite(base_speed, base_speed);
      }
      else {
        error = readPosition('f');
        P = error;
        D = error - previous_error;
        pd_value = (P * kp) + (D * kd);
        previous_error = error;
        left_motor_speed = base_speed - pd_value;
        right_motor_speed = base_speed + pd_value;
        motorWrite(left_motor_speed, right_motor_speed);
      }
      if (junction == 'c') {
        if (readJunction('f') == 'c') {
          motorWrite(0, 0);
          break;
        }
      }
      else if (junction == 'l') {
        if (readJunction('f') == 'l') {
          motorWrite(0, 0);
          break;
        }
      }
      else if (junction == 'r') {
        if (readJunction('f') == 'r') {
          motorWrite(0, 0);
          break;
        }
      }
    }
    if (count == 1) {
      if (stop_point == 'f') {
        motorWrite(-255, -255);
        delay(30);
        motorWrite(0, 0);
      }
      else if (stop_point == 'c') {
        while (1) {
          if (readJunction('f') != 'n') {
            motorWrite(base_speed, base_speed);
          }
          else {
            error = readPosition('f');
            P = error;
            D = error - previous_error;
            pd_value = (P * kp) + (D * kd);
            previous_error = error;
            left_motor_speed = base_speed - pd_value;
            right_motor_speed = base_speed + pd_value;
            motorWrite(left_motor_speed, right_motor_speed);
          }
          if (junction == 'l') {
            if (readPosition('l') > -200 && readPosition('l') < 200) {
              motorWrite(-255, -255);
              delay(30);
              motorWrite(0, 0);
              break;
            }
          }
          else if (junction == 'c') {
            if (readPosition('l') > -200 && readPosition('l') < 200 && readPosition('r') > -200 && readPosition('r') < 200) {
              motorWrite(-255, -255);
              delay(30);
              motorWrite(0, 0);
              break;
            }
          }
          else if (junction == 'r') {
            if (readPosition('r') > -200 && readPosition('r') < 200) {
              motorWrite(-255, -255);
              delay(30);
              motorWrite(0, 0);
              break;
            }
          }
        }
      }
      else if (stop_point == 'b') {
        while (1) {
          if (readJunction('f') != 'n') {
            motorWrite(base_speed, base_speed);
          }
          else {
            error = readPosition('f');
            P = error;
            D = error - previous_error;
            pd_value = (P * kp) + (D * kd);
            previous_error = error;
            left_motor_speed = base_speed - pd_value;
            right_motor_speed = base_speed + pd_value;
            motorWrite(left_motor_speed, right_motor_speed);
          }
          if (readJunction('b') != 'n') {
            motorWrite(-255, -255);
            delay(30);
            motorWrite(0, 0);
            break;
          }
        }
      }
    }
  }
}

void forwardLineDistance(int base_speed, float kp, float kd, unsigned int distance) {
  float error, pd_value, P, D, previous_error, left_motor_speed, right_motor_speed;
  int _brake_power = brake_power;
  setPowerBrake(255);
  while (1) {
    if (readJunction('f') != 'n') {
      motorWrite(base_speed, base_speed);
    }
    else {
      error = readPosition('f');
      P = error;
      D = error - previous_error;
      pd_value = (P * kp) + (D * kd);
      previous_error = error;
      left_motor_speed = base_speed - pd_value;
      right_motor_speed = base_speed + pd_value;
      motorWrite(left_motor_speed, right_motor_speed);
    }
    if (readDistance() <= distance) {
      motorWrite(0, 0);
      setPowerBrake(_brake_power);
      break;
    }
  }
}

void backwardLine(int base_speed, float kp, float kd) {
  float error, pd_value, P, D, left_motor_speed, right_motor_speed;
  if (readJunction('b') != 'n') {
    motorWrite(-base_speed, -base_speed);
  }
  else {
    error = readPosition('b');
    P = error;
    D = error - previous_error_fn;
    pd_value = (P * kp) + (D * kd);
    previous_error_fn = error;
    left_motor_speed = base_speed + pd_value;
    right_motor_speed = base_speed - pd_value;
    motorWrite(-left_motor_speed, -right_motor_speed);
  }
}

void backwardLineTime(int base_speed, float kp, float kd, unsigned int time) {
  float error, pd_value, P, D, previous_error, left_motor_speed, right_motor_speed;
  unsigned long int timer = millis();
  while (1) {
    if (readJunction('b') != 'n') {
      motorWrite(-base_speed, -base_speed);
    }
    else {
      error = readPosition('b');
      P = error;
      D = error - previous_error;
      pd_value = (P * kp) + (D * kd);
      previous_error = error;
      left_motor_speed = base_speed + pd_value;
      right_motor_speed = base_speed - pd_value;
      motorWrite(-left_motor_speed, -right_motor_speed);
    }
    if (millis() - timer >= time) {
      motorWrite(0, 0);
      break;
    }
  }
}

void backwardLine(int base_speed, float kp, float kd, char junction, char stop_point) {
  float error, pd_value, P, D, previous_error, left_motor_speed, right_motor_speed;
  while (1) {
    if (readJunction('b') != 'n') {
      motorWrite(-base_speed, -base_speed);
    }
    else {
      delay(100);
      break;
    }
  }
  while (1) {
    if (readJunction('b') != 'n') {
      motorWrite(-base_speed, -base_speed);
    }
    else {
      error = readPosition('b');
      P = error;
      D = error - previous_error;
      pd_value = (P * kp) + (D * kd);
      previous_error = error;
      left_motor_speed = base_speed + pd_value;
      right_motor_speed = base_speed - pd_value;
      motorWrite(-left_motor_speed, -right_motor_speed);
    }
    if (junction == 'c') {
      if (readJunction('b') == 'c') {
        motorWrite(0, 0);
        break;
      }
    }
    else if (junction == 'l') {
      if (readJunction('b') == 'l') {
        motorWrite(0, 0);
        break;
      }
    }
    else if (junction == 'r') {
      if (readJunction('b') == 'r') {
        motorWrite(0, 0);
        break;
      }
    }
  }
  if (stop_point == 'f') {
    motorWrite(255, 255);
    delay(30);
    motorWrite(0, 0);
  }
  else if (stop_point == 'c') {
    while (1) {
      if (readJunction('b') != 'n') {
        motorWrite(-base_speed, -base_speed);
      }
      else {
        error = readPosition('b');
        P = error;
        D = error - previous_error;
        pd_value = (P * kp) + (D * kd);
        previous_error = error;
        left_motor_speed = base_speed + pd_value;
        right_motor_speed = base_speed - pd_value;
        motorWrite(-left_motor_speed, -right_motor_speed);
      }
      if (junction == 'l') {
        if (readPosition('r') > -200 && readPosition('r') < 200) {
          motorWrite(255, 255);
          delay(30);
          motorWrite(0, 0);
          break;
        }
      }
      else if (junction == 'c') {
        if (readPosition('l') > -200 && readPosition('l') < 200 && readPosition('r') > -200 && readPosition('r') < 200) {
          motorWrite(255, 255);
          delay(30);
          motorWrite(0, 0);
          break;
        }
      }
      else if (junction == 'r') {
        if (readPosition('l') > -200 && readPosition('l') < 200) {
          motorWrite(255, 255);
          delay(30);
          motorWrite(0, 0);
          break;
        }
      }
    }
  }
  else if (stop_point == 'b') {
    while (1) {
      if (readJunction('f') != 'n') {
        motorWrite(-base_speed, -base_speed);
      }
      else {
        error = readPosition('b');
        P = error;
        D = error - previous_error;
        pd_value = (P * kp) + (D * kd);
        previous_error = error;
        left_motor_speed = base_speed + pd_value;
        right_motor_speed = base_speed - pd_value;
        motorWrite(-left_motor_speed, -right_motor_speed);
      }
      if (readJunction('f') != 'n') {
        motorWrite(255, 255);
        delay(30);
        motorWrite(0, 0);
        break;
      }
    }
  }
}

void backwardLine(int base_speed, float kp, float kd, char junction, char stop_point, int count) {
  float error, pd_value, P, D, previous_error, left_motor_speed, right_motor_speed;
  for (count; count > 0; count --) {
    while (1) {
      if (readJunction('b') != 'n') {
        motorWrite(-base_speed, -base_speed);
      }
      else {
        delay(100);
        break;
      }
    }
    while (1) {
      if (readJunction('b') != 'n') {
        motorWrite(-base_speed, -base_speed);
      }
      else {
        error = readPosition('b');
        P = error;
        D = error - previous_error;
        pd_value = (P * kp) + (D * kd);
        previous_error = error;
        left_motor_speed = base_speed + pd_value;
        right_motor_speed = base_speed - pd_value;
        motorWrite(-left_motor_speed, -right_motor_speed);
      }
      if (junction == 'c') {
        if (readJunction('b') == 'c') {
          motorWrite(0, 0);
          break;
        }
      }
      else if (junction == 'l') {
        if (readJunction('b') == 'l') {
          motorWrite(0, 0);
          break;
        }
      }
      else if (junction == 'r') {
        if (readJunction('b') == 'r') {
          motorWrite(0, 0);
          break;
        }
      }
    }
    if (count == 1) {
      if (stop_point == 'f') {
        motorWrite(255, 255);
        delay(30);
        motorWrite(0, 0);
      }
      else if (stop_point == 'c') {
        while (1) {
          if (readJunction('b') != 'n') {
            motorWrite(-base_speed, -base_speed);
          }
          else {
            error = readPosition('b');
            P = error;
            D = error - previous_error;
            pd_value = (P * kp) + (D * kd);
            previous_error = error;
            left_motor_speed = base_speed + pd_value;
            right_motor_speed = base_speed - pd_value;
            motorWrite(-left_motor_speed, -right_motor_speed);
          }
          if (junction == 'l') {
            if (readPosition('r') > -200 && readPosition('r') < 200) {
              motorWrite(255, 255);
              delay(30);
              motorWrite(0, 0);
              break;
            }
          }
          else if (junction == 'c') {
            if (readPosition('l') > -200 && readPosition('l') < 200 && readPosition('r') > -200 && readPosition('r') < 200) {
              motorWrite(255, 255);
              delay(30);
              motorWrite(0, 0);
              break;
            }
          }
          else if (junction == 'r') {
            if (readPosition('l') > -200 && readPosition('l') < 200) {
              motorWrite(255, 255);
              delay(30);
              motorWrite(0, 0);
              break;
            }
          }
        }
      }
      else if (stop_point == 'b') {
        while (1) {
          if (readJunction('f') != 'n') {
            motorWrite(-base_speed, -base_speed);
          }
          else {
            error = readPosition('b');
            P = error;
            D = error - previous_error;
            pd_value = (P * kp) + (D * kd);
            previous_error = error;
            left_motor_speed = base_speed + pd_value;
            right_motor_speed = base_speed - pd_value;
            motorWrite(-left_motor_speed, -right_motor_speed);
          }
          if (readJunction('f') != 'n') {
            motorWrite(255, 255);
            delay(30);
            motorWrite(0, 0);
            break;
          }
        }
      }
    }
  }
}

void turnLine(char direction, char sensor, int speed, bool set) {
  int _speed, _time;
  int _brake_power = brake_power;
  setPowerBrake(255);
  if (speed <= 1) {
    _speed = 50;
    _time = 7;
  }
  else if (speed == 2) {
    _speed = 150;
    _time = 10;
  }
  else if (speed >= 3) {
    _speed = 255;
    _time = 26;
  }
  if (sensor == 'f') {
    if (direction == 'l') {
      while (1) {
        if (map(readLineSensor(0), front_line_cal[0], front_background_cal[0], 0, 100) >= 50) {
          motorWrite(-_speed, _speed);
        }
        else {
          delay(100);
          motorWrite(0, 0);
          break;
        }
      }
      while (1) {
        if (speed > 2) {
          if (map(readLineSensor(4), front_line_cal[4], front_background_cal[4], 0, 100) >= 50) motorWrite(-_speed, _speed);
          else {
            motorWrite(255, -255);
            delay(_time);
            motorWrite(0, 0);
            break;
          }
        }
        else {
          if (map(readLineSensor(3), front_line_cal[3], front_background_cal[3], 0, 100) >= 50) motorWrite(-_speed, _speed);
          else {
            motorWrite(255, -255);
            delay(_time);
            motorWrite(0, 0);
            break;
          }
        }
      }
    }
    else if (direction == 'r') {
      while (1) {
        if (map(readLineSensor(6), front_line_cal[6], front_background_cal[6], 0, 100) >= 50) {
          motorWrite(_speed, -_speed);
        }
        else {
          delay(100);
          motorWrite(0, 0);
          break;
        }
      }
      while (1) {
        if (speed > 2) {
          if (map(readLineSensor(2), front_line_cal[2], front_background_cal[2], 0, 100) >= 50) motorWrite(_speed, -_speed);
          else {
            motorWrite(-255, 255);
            delay(_time);
            motorWrite(0, 0);
            break;
          }
        }
        else {
          if (map(readLineSensor(3), front_line_cal[3], front_background_cal[3], 0, 100) >= 50) motorWrite(_speed, -_speed);
          else {
            motorWrite(-255, 255);
            delay(_time);
            motorWrite(0, 0);
            break;
          }
        }
      }
    }
    if (set == 1) {
      delay(10);
      setToGo('f');
    }
    setPowerBrake(_brake_power);
  }
  else if (sensor == 'b') {
    if (direction == 'l') {
      while (1) {
        if (map(readLineSensor(7), back_line_cal[0], back_background_cal[0], 0, 100) >= 50) {
          motorWrite(-_speed, _speed);
        }
        else {
          delay(100);
          motorWrite(0, 0);
          break;
        }
      }
      while (1) {
        if (speed > 2) {
          if (map(readLineSensor(11), front_line_cal[4], front_background_cal[4], 0, 100) >= 50) motorWrite(-_speed, _speed);
          else {
            motorWrite(255, -255);
            delay(_time);
            motorWrite(0, 0);
            break;
          }
        }
        else {
          if (map(readLineSensor(10), front_line_cal[3], front_background_cal[3], 0, 100) >= 50) motorWrite(-_speed, _speed);
          else {
            motorWrite(255, -255);
            delay(_time);
            motorWrite(0, 0);
            break;
          }
        }
      }
    }
    else if (direction == 'r') {
      while (1) {
        if (map(readLineSensor(13), back_line_cal[6], back_background_cal[6], 0, 100) >= 50) {
          motorWrite(_speed, -_speed);
        }
        else {
          delay(100);
          motorWrite(0, 0);
          break;
        }
      }
      while (1) {
        if (speed > 2) {
          if (map(readLineSensor(9), front_line_cal[2], front_background_cal[2], 0, 100) >= 50) motorWrite(_speed, -_speed);
          else {
            motorWrite(-255, 255);
            delay(_time);
            motorWrite(0, 0);
            break;
          }
        }
        else {
          if (map(readLineSensor(10), front_line_cal[3], front_background_cal[3], 0, 100) >= 50) motorWrite(_speed, -_speed);
          else {
            motorWrite(-255, 255);
            delay(_time);
            motorWrite(0, 0);
            break;
          }
        }
      }
    }
    if (set == 1) {
      delay(10);
      setToGo('b');
    }
    setPowerBrake(_brake_power);
  }
}

void turnDegree(int degree) {
  resetGyro();
  int error, pd_value, kp, kd, previous_error, left_motor_speed, right_motor_speed;
  unsigned long int timer = millis();
  while (1) {
    error = (readRotation() - degree);
    kp = error;
    kd = error - previous_error;
    pd_value = (kp * 2) + (kd * 5);
    previous_error = error;
    left_motor_speed = 0 - pd_value;
    right_motor_speed = 0 + pd_value;
    if (left_motor_speed > 100) left_motor_speed = 100;
    else if (left_motor_speed < -100) left_motor_speed = -100;
    if (right_motor_speed > 100) right_motor_speed = 100;
    else if (right_motor_speed < -100) right_motor_speed = -100;
    motorWrite(left_motor_speed, right_motor_speed);
    if (abs(error) <= 5) {
      if (degree < 20) {
        motorWrite(255, -255);
        delay(20);
      }
      else if (degree > 20) {
        motorWrite(-255, 255);
        delay(20);
      }
      motorWrite(0, 0);
      break;
    }
  }
  timer = millis();
  while (1) {
    if (millis() - timer < 300) {
      error = (readRotation() - degree);
      kp = error;
      kd = error - previous_error;
      pd_value = (kp * 2) + (kd * 50);
      previous_error = error;
      left_motor_speed = -pd_value;
      right_motor_speed = pd_value;
      motorWrite(left_motor_speed, right_motor_speed);
    }
    else {
      motorWrite(0, 0);
      break;
    }
  }
}

void robotProcess() {
  if (readButtonC()) {
    if (millis() - timer_button_c >= 3000) calibrateLineSensor(calibrate_mode);
  }
  else timer_button_c = millis();

  if (readButtonB()) {
    if (millis() - timer_button_b >= 3000) calibrateIMU();
  }
  else timer_button_b = millis();
}

void RobotSetup() {
  Serial3.begin(115200);

  pinMode(motor_left_1, OUTPUT);
  pinMode(motor_left_2, OUTPUT);
  pinMode(motor_right_1, OUTPUT);
  pinMode(motor_right_2, OUTPUT);
  pinMode(mux_pin_0, OUTPUT);
  pinMode(mux_pin_1, OUTPUT);
  pinMode(mux_pin_2, OUTPUT);
  pinMode(mux_pin_3, OUTPUT);
  pinMode(button_a_pin, INPUT_PULLUP);
  pinMode(button_b_pin, INPUT_PULLUP);
  pinMode(button_c_pin, INPUT_PULLUP);

  digitalWrite(mux_pin_0, 0);
  digitalWrite(mux_pin_1, 0);
  digitalWrite(mux_pin_2, 0);
  digitalWrite(mux_pin_3, 0);

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.display();

  pixels.begin();
  for (int j = 0; j < 256; j++) {
    for (int i = 0; i < pixels.numPixels(); i++) pixels.setPixelColor(i, wheel((i + j) & 255));
    pixels.show();
    delay(3);
  }
  for (byte i = 255; i > 0; i --) {
    pixels.setBrightness(i);
    pixels.show();
    delay(2);
  }
  turnOffLed();
  pixels.setBrightness(255);
  for (int i = 0; i < pixels.numPixels(); i++) pixels.setPixelColor(i, red);

  timer.setPrescaleFactor(100);
  timer.setOverflow(32761);
  timer.attachInterrupt(robotProcess);
  timer.refresh();
  timer.resume();

  readLineFromEEPROM();

  delay(1000);

  calib.accelBias[0] = 0;
  calib.accelBias[1] = 0;
  calib.accelBias[2] = 0;
  calib.gyroBias[0] = -1.26;
  calib.gyroBias[1] = -0.49;
  calib.gyroBias[2] = 1.21;
  calib.valid = true;

  IMU.init(calib, 0x68);
  IMU.setGyroRange(500);
  IMU.setAccelRange(2);

  playSound(1000, 100);
  playSound(2000, 100);

  delay(1000);
}

void microbitRun() {
  if (Serial3.available()) {
    byte inByte = Serial3.read();
    char inChar = (char)inByte;
    if (inChar == '\n') {
      stringComplete = true;
    }
    else {
      if (inByte >= 32) {
        inputString += inChar;
      }
    }
  }

  if (stringComplete) {
    Serial.println(inputString);
    if (splitString(inputString, 0) == "RS") {
      String sensor = splitString(inputString, 1);
      Serial3.println(readLineSensor(sensor.toInt()));
    }
    else if (splitString(inputString, 0) == "RD") {
      int distance = readDistance();
      Serial3.println(distance);
    }
    else if (splitString(inputString, 0) == "RP") {
      char sensor[2];
      splitString(inputString, 1).toCharArray(sensor, 2);
      Serial3.println(readPosition(sensor[0]));
    }
    else if (splitString(inputString, 0) == "CS") {
      String mode = splitString(inputString, 1);
      setCalibrateMode(mode.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "CP") {
      String compensate_left = splitString(inputString, 1);
      String compensate_right = splitString(inputString, 2);
      setCompensateMotor(compensate_left.toInt(), compensate_right.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "SP") {
      String power_brake = splitString(inputString, 1);
      setPowerBrake(power_brake.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "MC") {
      String speed_left = splitString(inputString, 1);
      String speed_right = splitString(inputString, 2);
      motorWrite(speed_left.toInt(), speed_right.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "TD") {
      String degree = splitString(inputString, 1);
      turnDegree(degree.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "SC") {
      String servo = splitString(inputString, 1);
      String degree = splitString(inputString, 2);
      servoWrite(servo.toInt(), degree.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "PS") {
      String frequency = splitString(inputString, 1);
      String duration = splitString(inputString, 2);
      playSound(frequency.toInt(), duration.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "RB") {
      String button = splitString(inputString, 1);
      if (button == "0") Serial3.println(readButtonA());
      else if (button == "1") Serial3.println(readButtonB());
      else if (button == "2") Serial3.println(readButtonC());
    }
    else if (splitString(inputString, 0) == "SL") {
      char led[2];
      uint32_t color[7] = {0, 0, 0, 0, 0, 0, 0};
      splitString(inputString, 1).toCharArray(led, 2);
      for (byte i = 0; i < 7; i ++) {
        if (splitString(inputString, i + 2) == "1") color[i] = red;
        else if (splitString(inputString, i + 2) == "2") color[i] = green;
        else if (splitString(inputString, i + 2) == "3") color[i] = blue;
        else if (splitString(inputString, i + 2) == "4") color[i] = white;
        else if (splitString(inputString, i + 2) == "5") color[i] = black;
      }
      if (color[6] > 0) setLedColor(led[0], color[0], color[1], color[2], color[3], color[4], color[5], color[6]);
      else setLedColor(led[0], color[0], color[1], color[2], color[3], color[4]);
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "SA") {
      uint32_t color  = 0;
      if (splitString(inputString, 1) == "1") color = red;
      else if (splitString(inputString, 1) == "2") color = green;
      else if (splitString(inputString, 1) == "3") color = blue;
      else if (splitString(inputString, 1) == "4") color = white;
      else if (splitString(inputString, 1) == "5") color = black;
      setLedColor(color);
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "PL") {
      char led[2];
      splitString(inputString, 1).toCharArray(led, 2);
      String status = splitString(inputString, 2);
      if (status == "0") turnOffLed(led[0]);
      else if (status == "1") turnOnLed(led[0]);
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "PA") {
      String status = splitString(inputString, 1);
      if (status == "0") turnOffLed();
      else if (status == "1") turnOnLed();
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "SB") {
      String brightness = splitString(inputString, 1);
      setLedBrightness(brightness.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "FD") {
      String speed = splitString(inputString, 1);
      String kp = splitString(inputString, 2);
      String kd = splitString(inputString, 3);
      String distance = splitString(inputString, 4);
      forwardLineDistance(speed.toInt(), kp.toFloat(), kd.toFloat(), distance.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "FT") {
      String speed = splitString(inputString, 1);
      String kp = splitString(inputString, 2);
      String kd = splitString(inputString, 3);
      String time = splitString(inputString, 4);
      forwardLineTime(speed.toInt(), kp.toFloat(), kd.toFloat(), time.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "BT") {
      String speed = splitString(inputString, 1);
      String kp = splitString(inputString, 2);
      String kd = splitString(inputString, 3);
      String time = splitString(inputString, 4);
      backwardLineTime(speed.toInt(), kp.toFloat(), kd.toFloat(), time.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "FL") {
      char intersection[2];
      char stop_position[2];
      String speed = splitString(inputString, 1);
      String kp = splitString(inputString, 2);
      String kd = splitString(inputString, 3);
      splitString(inputString, 4).toCharArray(intersection, 2);
      splitString(inputString, 5).toCharArray(stop_position, 2);
      forwardLine(speed.toInt(), kp.toFloat(), kd.toFloat(), intersection[0], stop_position[0]);
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "FC") {
      char intersection[2];
      char stop_position[2];
      String speed = splitString(inputString, 1);
      String kp = splitString(inputString, 2);
      String kd = splitString(inputString, 3);
      String count = splitString(inputString, 6);
      splitString(inputString, 4).toCharArray(intersection, 2);
      splitString(inputString, 5).toCharArray(stop_position, 2);
      forwardLine(speed.toInt(), kp.toFloat(), kd.toFloat(), intersection[0], stop_position[0], count.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "BL") {
      char intersection[2];
      char stop_position[2];
      String speed = splitString(inputString, 1);
      String kp = splitString(inputString, 2);
      String kd = splitString(inputString, 3);
      splitString(inputString, 4).toCharArray(intersection, 2);
      splitString(inputString, 5).toCharArray(stop_position, 2);
      backwardLine(speed.toInt(), kp.toFloat(), kd.toFloat(), intersection[0], stop_position[0]);
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "BC") {
      char intersection[2];
      char stop_position[2];
      String speed = splitString(inputString, 1);
      String kp = splitString(inputString, 2);
      String kd = splitString(inputString, 3);
      String count = splitString(inputString, 6);
      splitString(inputString, 4).toCharArray(intersection, 2);
      splitString(inputString, 5).toCharArray(stop_position, 2);
      backwardLine(speed.toInt(), kp.toFloat(), kd.toFloat(), intersection[0], stop_position[0], count.toInt());
      Serial3.println("OK");
    }
    else if (splitString(inputString, 0) == "TL") {
      char direction[2];
      char sensor[2];
      splitString(inputString, 1).toCharArray(direction, 2);
      splitString(inputString, 2).toCharArray(sensor, 2);
      String speed = splitString(inputString, 3);
      String align = splitString(inputString, 4);
      turnLine(direction[0], sensor[0], speed.toInt(), align.toInt());
      Serial3.println("OK");
    }
    inputString = "";
    stringComplete = false;
  }
}

#endif